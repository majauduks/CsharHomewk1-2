﻿bool flag = true;


while (flag)
{
    int[] arrayNumbers = new int[6]; ;

    Console.WriteLine("Enter the first number");
    string numberOne = Console.ReadLine();
    bool isOneOkay = int.TryParse(numberOne, out arrayNumbers[1]);
    Console.WriteLine("Enter the second number");
    string numberTwo = Console.ReadLine();
    bool isTwoOkay = int.TryParse(numberTwo, out arrayNumbers[2]);

    Console.WriteLine("Enter the third number");
    string numberThree = Console.ReadLine();
    bool isThreeOkay = int.TryParse(numberThree, out arrayNumbers[3]);

    Console.WriteLine("Enter the fourth number");
    string numberFour = Console.ReadLine();
    bool isFourOkay = int.TryParse(numberFour, out arrayNumbers[4]);

    Console.WriteLine("Enter the fifth number");
    string numberFive = Console.ReadLine();
    bool isFiveOkay = int.TryParse(numberFive, out arrayNumbers[5]);

    Console.WriteLine("Enter the sixth number");
    string numberSix = Console.ReadLine();
    bool isSixOkay = int.TryParse(numberSix, out arrayNumbers[5]);



    if (!isOneOkay || !isTwoOkay || !isThreeOkay || !isFourOkay || !isFiveOkay || !isSixOkay)
    {
        Console.WriteLine("Enter a valid number!");
        continue;
    }


    int average = 0;
    for (int i = 0; i < arrayNumbers.Length; i ++)
    {
        average += arrayNumbers[i];
    }

Console.WriteLine("The average of the four numbers is:" + average/arrayNumbers.Length);
    flag = false;
}
