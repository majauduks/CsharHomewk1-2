﻿string[] G1 = {
"Maja",
"Sofi",
"Milena",
"Alek",
"Kate"};

string[] G2 = {
    "Trte",
    "Mrte",
    "Blabla",
    "Mi se spie",
    "DrnDrnJarinja"
};


bool flag = false;

while (!flag)
{

    Console.WriteLine("Izberi 1 ili 2");
    string izbor = Console.ReadLine();
    bool izborDobar = int.TryParse(izbor, out int izborNumber);

    switch (izborNumber)
    {
        case 1:
            for (int i = 0; i < G1.Length; i++)
            {
                Console.WriteLine(G1[i]);
            }
            flag = true;
            break;

        case 2:
            for (int i = 0; i < G2.Length; i++)
            {
                Console.WriteLine(G2[i]);
            }
            flag=true;
            break;

        default:
            Console.WriteLine("Izberi samo pomegju 1 i 2");
            continue;
    }


}