﻿// See https://aka.ms/new-console-template for more information




bool flag = true;

while (flag)
{
Console.WriteLine("Enter the first number");
string firstInput = Console.ReadLine();
bool isFirstInputOkay = int.TryParse(firstInput, out int firstNumber);
Console.WriteLine("Enter the second number");
string secondInput = Console.ReadLine();
bool isSecondInputOkay = int.TryParse(secondInput, out int secondNumber);

Console.WriteLine("Enter the operation");
string operation = Console.ReadLine();


    if (isFirstInputOkay && isSecondInputOkay)
    {
        switch (operation)
        {
            case "+":
                Console.WriteLine(firstNumber + secondNumber);
                break;
            case "-":
                Console.WriteLine(firstNumber - secondNumber);
                break;
            case "*":
                Console.WriteLine(firstNumber * secondNumber);
                break;
            case "/":
                Console.WriteLine(firstNumber / secondNumber);
                break;
            default:
                Console.WriteLine(firstNumber + secondNumber);
                break;
                flag = false;
                continue;

        }
    }
    else
    {

        Console.WriteLine("Enter a valid number");
        continue;

    }

}
