﻿// See https://aka.ms/new-console-template for more information
bool flag = true;


while (flag)
{

    Console.WriteLine("Enter the first number");
    string numberOne = Console.ReadLine();
    bool isOneOkay = int.TryParse(numberOne, out int number1);
    Console.WriteLine("Enter the second number");
    string numberTwo = Console.ReadLine();
    bool isTwoOkay = int.TryParse(numberTwo, out int number2);

    Console.WriteLine("Enter the third number");
    string numberThree = Console.ReadLine();
    bool isThreeOkay = int.TryParse(numberThree, out int number3);

    Console.WriteLine("Enter the fourth number");
    string numberFour = Console.ReadLine();
    bool isFourOkay = int.TryParse(numberFour, out int number4);




    if (!isOneOkay || !isTwoOkay || !isThreeOkay || !isFourOkay)
    {
        Console.WriteLine("Enter a valid number!");
        continue;
    }


    int average = 0;
    average=(number1+number2+ number3 + number4)/4;

Console.WriteLine("The average of the four numbers is:" + average);
    flag = false;
}
