﻿
bool flag = true;
while (flag)
{

Console.WriteLine("Enter the first number");
string numberOne = Console.ReadLine();
bool isOneOkay = int.TryParse(numberOne, out int number1);
    Console.WriteLine("Enter the second number");
string numberTwo = Console.ReadLine();
bool isTwoOkay = int.TryParse(numberTwo, out int number2);
    
    if (!isOneOkay || !isTwoOkay)
    {
        Console.WriteLine("Enter a valid number!");
        continue;
    }


    Console.WriteLine("Before swapping, number 1: " + number1 + " number 2: " + number2);
int temporaryHold = 0;
    temporaryHold = number1;
    number1 = number2;
    number2 = temporaryHold;
    Console.WriteLine("After swapping, number 1:  " + number1 + " number 2: " + number2);
    flag=false;


}

